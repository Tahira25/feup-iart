# C5.0

The **c5.0** executable was obtained using the following instructions:

- Extract **C50.tgz**
- Open **Terminal** and browse to the extracted folder
- Run the command `make`
